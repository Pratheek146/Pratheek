// src/App.js
import React from 'react';
import './styles.css';

function App() {
  return (
    <div className="App">
      <h1>React App with CI/CD Pipeline</h1>
      <p>This React app is deployed using Jenkins, Docker, and Kubernetes.</p>
    </div>
  );
}

export default App;